<?
$apikey = '531ddfb92419d';
$starspath = "http://www.myastrologycharts.com/astroservice/";
$enginepath = "http://www.myastrologycharts.com/";
$imagepath = "http://www.myastrologycharts.com/serviceimages";
$enginename = "engineservice.php";
?>
